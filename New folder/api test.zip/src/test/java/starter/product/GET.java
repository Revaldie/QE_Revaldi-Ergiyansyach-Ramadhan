package starter.product;

import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.junit.Assert;

import static net.serenitybdd.rest.SerenityRest.given;

public class GET {
    protected static String url = "https://be-qa.alta.id/api";
    @Step("admin on postman app")
    public void AdminonPostmanApp(){
    }

    @Step("admin add url")
    public String addUrlProducts (){
        return url + "/products";
    }

    @Step("input GET as a method")
    public void inputGETAsAMethod(){
        SerenityRest.given().get(addUrlProducts());

    }

    @Step("admin click send")
    public void adminClickSend() {
    }
    @Step("response shows = {int} OK")
    public void responseShowsOK() {

        given().when().get(url).then().assertThat().statusCode(200);
    }

    @Step("Response shows all products")
    public void ResponseShowsAllProducts(){
            Response response = SerenityRest.lastResponse();

            String name = response.getBody().jsonPath().get("data.Name[0]");
            Assert.assertEquals(name, "Pepaya");

            int ID = response.getBody().jsonPath().get("data.ID[0]");
            Assert.assertEquals(ID, 110);

    }
}
