package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.product.GET;

public class ProductSteps {
    @Steps
    GET Get;

    @When("admin add url")
    public void addUrlProducts(){
        Get.addUrlProducts();
    }

    @Then("response shows = {int} OK")
    public void responseShowsOK(int arg0) {
        Get.responseShowsOK();
    }
    @And("Response shows all products")
    public void ResponseShowsAllProducts(){
        Get.ResponseShowsAllProducts();
    }
}
